


export class User {
    name
    email
    verified

}