import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
 templateUrl: './app.component.html',
 //template: 'Welcome',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Welcome to my-app';
}
