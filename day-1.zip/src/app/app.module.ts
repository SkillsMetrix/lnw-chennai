import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyappComponent } from './components/myapp/myapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SummaryPipe } from './shared/pipes/summary.pipe';
import { ChildModule } from './shared.module';
import { UserformComponent } from './components/userform/userform.component';
 import { FormsModule, ReactiveFormsModule } from '@angular/forms'
 import  { HttpClientModule } from '@angular/common/http'
@NgModule({
  // contains components,pipes and directives
  declarations: [
    AppComponent,
    MyappComponent,
    HeaderComponent,
    FooterComponent,
    UserformComponent,
   ],
  // modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChildModule,
    FormsModule,ReactiveFormsModule,HttpClientModule
  ],
  //services
   // first component to load
  bootstrap: [AppComponent]
})
export class AppModule { }
