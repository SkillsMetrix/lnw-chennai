import { Pipe, PipeTransform } from "@angular/core";


@Pipe({
    name: 'summary'
})

export class SummaryPipe implements PipeTransform {
    transform(data: string,limit:number) {
        return data.substring(0, limit)
    }
}