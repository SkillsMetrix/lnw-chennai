import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { SummaryPipe } from './shared/pipes/summary.pipe';

@NgModule({
    declarations: [

        SummaryPipe
    ],
    exports: [SummaryPipe],
    // modules
    imports: [
        BrowserModule,

    ],

})
export class ChildModule { }
