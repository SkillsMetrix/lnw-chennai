import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../shared/services/UserService.service';

@Component({
  selector: 'app-userform',
  templateUrl: './userform.component.html',
  styleUrl: './userform.component.css'
})
export class UserformComponent {

  myForm: FormGroup
  uname: FormControl
  password: FormControl
  email: FormControl

  createFormControl() {
    this.uname = new FormControl('',Validators.required)
    this.password = new FormControl('',[Validators.required,Validators.minLength(6)])
    this.email = new FormControl('',[Validators.required,Validators.email,this.emailDomainValidator])
  }
  createForm() {
    this.myForm = new FormGroup({
      uname: this.uname,
      password: this.password,
      email: this.email
    })
  }
  constructor(private us:UserService) {
    this.createFormControl()
    this.createForm()
   }
  addUser(){
   // console.log(this.myForm.value);
   this.us.addUser(this.myForm.value)
    
  }
   users:any[]
  loadDataFromDB(){
    this.us.loadUsers().subscribe((res)=>{
       const myArray=[]
       for(let key in res){
        myArray.push(res[key])
       }
       this.users=myArray
    })
  }
  emailDomainValidator(control: FormControl){
    let email= control.value
    if(email && email.indexOf('@') != -1){
      let [before,domain]= email.split('@')
      if(domain !=='lnw.com'){
        return {
          emailDomain:{
            parseDomain:domain
          }
        }
      }
    }
    return null;
  }
}
