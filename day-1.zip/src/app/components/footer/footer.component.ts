import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {

  userdata={
    username:'Administrator',
    income:99808,
    rating:4.889,
    DOJ: new Date('11/11/2011'),
    details:'the user information',
    greetings:'Hello and welcome to pipe'
  }
}
