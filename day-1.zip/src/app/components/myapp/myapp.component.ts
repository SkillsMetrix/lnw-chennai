import { Component } from '@angular/core';
 
@Component({
  selector: 'app-myapp',
  templateUrl: './myapp.component.html',
  styleUrl: './myapp.component.css',
 })
export class MyappComponent {

}
