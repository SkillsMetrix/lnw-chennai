import { Component, inject, OnInit } from '@angular/core';
import { UserService } from '../../shared/services/UserService.service';
import { User } from '../../User';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
 
})
export class HeaderComponent implements OnInit {
  constructor(private us:UserService){
    this.userdata=this.us.userdata()
  }
   //udata= inject(UserService)

  userdata:any=[];
     user!: User

ngOnInit(): void {
    this.user={
      name:'admin',
      email:'admin@mail.com',
      verified:true
    }
}

}
