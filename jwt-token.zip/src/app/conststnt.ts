export const Constant = {
    EN_KEY : "123Wer"
}