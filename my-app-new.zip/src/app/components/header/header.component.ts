import { Component } from '@angular/core';
import { UserService } from 'src/app/shared/services/UserService.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

  users: string[] = []

  constructor(private us: UserService) {
    this.users = this.us.loadUsers()}
 
people= [
  {
    name:'duglos',
    country:'USA'
  },
  {
    name:'shanthi',
    country:'India'
  },
  {
    name:'peter',
    country:'Australia'
  }
]
getColor(country: string) {
    switch (country) {
      case 'Australia':
        return 'blue'
      case 'USA':
        return 'green'
      case 'India':
        return 'purple'
        default:
          return null
    }
  }

}
