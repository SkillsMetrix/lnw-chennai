import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { UserService } from './shared/services/UserService.service';
import { FormsModule } from '@angular/forms';
import { FormdemoComponent } from './formdemo/formdemo.component'

@NgModule({
  // contains  components,pipes and directives
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent,
    FormdemoComponent
  ],
  //contains modules
  imports: [
    BrowserModule,FormsModule
  ],
  //services
  providers: [UserService],
  //first app
  bootstrap: [AppComponent]
})
export class AppModule { }
